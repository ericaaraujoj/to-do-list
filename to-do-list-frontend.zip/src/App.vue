<template>
  <div>
    <h1>To-Do List</h1>

    <input v-model="newTask.title" placeholder="Título" />
    <input v-model="newTask.description" placeholder="Descrição" />
    <select v-model="newTask.status">
      <option value="não iniciado">Não Iniciado</option>
      <option value="em andamento">Em Andamento</option>
      <option value="concluído">Concluído</option>
    </select>
    <button @click="createTask">Adicionar</button>

    <ul>
      <li v-for="task in tasks" :key="task.id">
        {{ task.id }} - {{ task.title }} - {{ task.status }}
        <button @click="getTask(task.id)">Ver</button>
      </li>
    </ul>

    <div v-if="selectedTask">
      <h2>Tarefa Selecionada</h2>
      <p>ID: {{ selectedTask.id }}</p>
      <p>Título: {{ selectedTask.title }}</p>
      <p>Descrição: {{ selectedTask.description }}</p>
      <p>Status: {{ selectedTask.status }}</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      newTask: {
        title: '',
        description: '',
        status: 'não iniciado'
      },
      tasks: [],
      selectedTask: null
    }
  },
  methods: {
    async createTask() {
      if (!this.newTask.title) return
      await axios.post('http://localhost:8080/tasks', this.newTask)
      this.newTask = { title: '', description: '', status: 'não iniciado' }
      this.getTasks()
    },
    async getTasks() {
      const response = await axios.get('http://localhost:8080/tasks')
      this.tasks = response.data
    },
    async getTask(id) {
      const response = await axios.get(`http://localhost:8080/tasks/${id}`)
      this.selectedTask = response.data
    }
  },
  mounted() {
    this.getTasks()
  }
}
</script>
